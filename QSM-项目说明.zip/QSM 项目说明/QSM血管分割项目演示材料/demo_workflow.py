#!/usr/bin/env python3
"""
自动化演示脚本 - QSM 医学影像分割与可视化系统
展示完整工作流：数据加载 → 分割 → 血管增强 → 统计分析
"""

import sys
import time
import numpy as np
from pathlib import Path
from datetime import datetime

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'new'))

print("=" * 80)
print("QSM 医学影像分割与可视化系统 - 自动化演示")
print("=" * 80)
print(f"演示时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"项目路径: {Path(__file__).parent.parent.parent / 'new'}")
print("=" * 80)
print()

# Step 1: 导入依赖
print("[1/6] 导入依赖库...")
start_time = time.time()
try:
    import nibabel as nib
    from skimage.filters import threshold_otsu, frangi
    from skimage.morphology import binary_closing, binary_opening, remove_small_objects, ball
    from scipy.ndimage import binary_fill_holes, gaussian_filter
    print(f"✓ 依赖库导入成功 ({time.time() - start_time:.2f}s)")
    print(f"  - nibabel: {nib.__version__}")
    print(f"  - numpy: {np.__version__}")
except Exception as e:
    print(f"✗ 依赖库导入失败: {e}")
    sys.exit(1)
print()

# Step 2: 加载数据
print("[2/6] 加载 QSM 数据...")
start_time = time.time()
data_path = Path('/Users/maoyuanyang/Desktop/qsa-mra/magvessel.nii.gz')
try:
    nii = nib.load(str(data_path))
    data = nii.get_fdata()
    print(f"✓ 数据加载成功 ({time.time() - start_time:.2f}s)")
    print(f"  - 文件路径: {data_path}")
    print(f"  - 数据形状: {data.shape}")
    print(f"  - 数据类型: {data.dtype}")
    print(f"  - 体素间距: {nii.header.get_zooms()[:3]} mm")
    print(f"  - 信号范围: [{data.min():.4f}, {data.max():.4f}]")
    print(f"  - 数据大小: {data.nbytes / 1024 / 1024:.2f} MB")
except Exception as e:
    print(f"✗ 数据加载失败: {e}")
    sys.exit(1)
print()

# Step 3: 快速分割（传统方法）
print("[3/6] 执行快速分割（Otsu + 形态学）...")
start_time = time.time()
try:
    # Otsu 阈值
    threshold = threshold_otsu(data)
    print(f"  → Otsu 阈值计算: {threshold:.6f}")

    # 二值化
    binary_mask = data > threshold
    print(f"  → 二值化完成，初始体素数: {binary_mask.sum():,}")

    # 形态学处理
    print(f"  → 形态学闭运算（去除小孔洞）...")
    binary_mask = binary_closing(binary_mask, ball(3))

    print(f"  → 形态学开运算（去除小噪点）...")
    binary_mask = binary_opening(binary_mask, ball(2))

    print(f"  → 填充内部孔洞...")
    binary_mask = binary_fill_holes(binary_mask)

    print(f"  → 移除小连通域（<1000 体素）...")
    binary_mask = remove_small_objects(binary_mask, min_size=1000)

    # 生成概率图
    probability_map = gaussian_filter(binary_mask.astype(float), sigma=1.0)

    # 统计信息
    voxel_count = binary_mask.sum()
    voxel_volume = np.prod(nii.header.get_zooms()[:3])
    total_volume_mm3 = voxel_count * voxel_volume
    total_volume_cm3 = total_volume_mm3 / 1000
    coverage = (voxel_count / binary_mask.size) * 100

    print(f"✓ 快速分割完成 ({time.time() - start_time:.2f}s)")
    print(f"  - 分割阈值: {threshold:.6f}")
    print(f"  - 分割体素数: {voxel_count:,}")
    print(f"  - 脑组织体积: {total_volume_mm3:.2f} mm³ ({total_volume_cm3:.2f} cm³)")
    print(f"  - 覆盖率: {coverage:.2f}%")

    # 保存结果
    output_dir = Path('/Users/maoyuanyang/Desktop/qsa-mra/new/segmentation_results')
    output_dir.mkdir(parents=True, exist_ok=True)

    mask_nii = nib.Nifti1Image(binary_mask.astype(np.uint8), nii.affine, nii.header)
    mask_path = output_dir / f'brain_mask_quick_{datetime.now().strftime("%Y%m%d_%H%M%S")}.nii.gz'
    nib.save(mask_nii, str(mask_path))

    prob_nii = nib.Nifti1Image(probability_map.astype(np.float32), nii.affine, nii.header)
    prob_path = output_dir / f'brain_probability_quick_{datetime.now().strftime("%Y%m%d_%H%M%S")}.nii.gz'
    nib.save(prob_nii, str(prob_path))

    print(f"  - 保存路径: {output_dir}")

except Exception as e:
    print(f"✗ 快速分割失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
print()

# Step 4: Frangi 血管增强
print("[4/6] 执行 Frangi 血管增强...")
start_time = time.time()
try:
    # 只处理中间切片以加速演示
    mid_slice = data.shape[2] // 2
    slice_data = data[:, :, mid_slice]

    print(f"  → 处理中间切片 (z={mid_slice})...")
    frangi_result = frangi(
        slice_data,
        sigmas=range(1, 5, 1),
        black_ridges=False
    )

    vessel_count = (frangi_result > 0.01).sum()
    vessel_ratio = (vessel_count / frangi_result.size) * 100

    print(f"✓ Frangi 血管增强完成 ({time.time() - start_time:.2f}s)")
    print(f"  - 处理切片: {mid_slice}/{data.shape[2]}")
    print(f"  - 血管响应范围: [{frangi_result.min():.6f}, {frangi_result.max():.6f}]")
    print(f"  - 血管像素数: {vessel_count:,}")
    print(f"  - 血管占比: {vessel_ratio:.2f}%")

except Exception as e:
    print(f"✗ Frangi 血管增强失败: {e}")
    import traceback
    traceback.print_exc()
print()

# Step 5: ROI 统计分析
print("[5/6] ROI 统计分析...")
start_time = time.time()
try:
    masked_data = data[binary_mask]

    stats = {
        'mean': masked_data.mean(),
        'std': masked_data.std(),
        'min': masked_data.min(),
        'max': masked_data.max(),
        'median': np.median(masked_data),
        'q25': np.percentile(masked_data, 25),
        'q75': np.percentile(masked_data, 75)
    }

    print(f"✓ 统计分析完成 ({time.time() - start_time:.2f}s)")
    print(f"  - 平均信号强度: {stats['mean']:.6f} ± {stats['std']:.6f}")
    print(f"  - 信号范围: [{stats['min']:.6f}, {stats['max']:.6f}]")
    print(f"  - 中位数: {stats['median']:.6f}")
    print(f"  - 四分位数: Q1={stats['q25']:.6f}, Q3={stats['q75']:.6f}")

except Exception as e:
    print(f"✗ 统计分析失败: {e}")
print()

# Step 6: 生成报告
print("[6/6] 生成分析报告...")
report_path = Path(__file__).parent / f'analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'
try:
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("QSM 医学影像分割与可视化系统 - 分析报告\n")
        f.write("=" * 80 + "\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"数据文件: {data_path}\n\n")

        f.write("【数据信息】\n")
        f.write(f"  数据形状: {data.shape}\n")
        f.write(f"  体素间距: {nii.header.get_zooms()[:3]} mm\n")
        f.write(f"  信号范围: [{data.min():.4f}, {data.max():.4f}]\n\n")

        f.write("【分割结果】\n")
        f.write(f"  分割方法: Otsu + 形态学\n")
        f.write(f"  分割阈值: {threshold:.6f}\n")
        f.write(f"  分割体素数: {voxel_count:,}\n")
        f.write(f"  脑组织体积: {total_volume_cm3:.2f} cm³\n")
        f.write(f"  覆盖率: {coverage:.2f}%\n\n")

        f.write("【信号统计】\n")
        f.write(f"  平均值: {stats['mean']:.6f}\n")
        f.write(f"  标准差: {stats['std']:.6f}\n")
        f.write(f"  中位数: {stats['median']:.6f}\n")
        f.write(f"  最小值: {stats['min']:.6f}\n")
        f.write(f"  最大值: {stats['max']:.6f}\n\n")

        f.write("【输出文件】\n")
        f.write(f"  分割 Mask: {mask_path}\n")
        f.write(f"  概率图: {prob_path}\n")
        f.write(f"  分析报告: {report_path}\n")
        f.write("=" * 80 + "\n")

    print(f"✓ 报告生成完成: {report_path}")
except Exception as e:
    print(f"✗ 报告生成失败: {e}")
print()

print("=" * 80)
print("演示完成！")
print("=" * 80)
print()
print("【下一步操作】")
print("1. 启动 napari 可视化界面:")
print("   python mri_nifti_quant/render_napari.py")
print()
print("2. 在 napari 中测试交互功能:")
print("   - 点击 '⚡ 快速分割' 按钮")
print("   - 点击 '🩸 Frangi 血管增强' 按钮")
print("   - 调整渲染参数（MIP/ISO 模式切换）")
print()
print("3. 查看分析报告:")
print(f"   cat {report_path}")
print("=" * 80)
