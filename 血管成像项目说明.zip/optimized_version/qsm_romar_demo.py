#!/usr/bin/env python3
"""
QSM-ROMAR Pipeline in Python
优化版本：修复bug并改进参数以获得更好的血管对比度
"""

import numpy as np
import nibabel as nib
from scipy.ndimage import gaussian_filter
from scipy.fft import fftn, ifftn, fftshift, ifftshift
from scipy.signal import convolve
import matplotlib.pyplot as plt
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')


# ========== ROMAR Phase 实现 ==========
class ROMARPhase:
    """ROMAR相位合并算法"""

    def __init__(self, TF=10, ref_channel=0, use_phase_correction=True, enhance_phase=False):
        self.TF = TF
        self.ref_channel = ref_channel
        self.use_phase_correction = use_phase_correction
        self.enhance_phase = enhance_phase

    def process(self, phase_maps):
        """
        处理多通道相位图

        Args:
            phase_maps: [nx, ny, nz, ncoils] 相位数据 (弧度)

        Returns:
            phase_combined: [nx, ny, nz] 合并后的相位
            W: [nx, ny, nz, ncoils] SMF权重
        """
        print(f"ROMAR Phase: 输入尺寸 {phase_maps.shape}, TF={self.TF}")

        # Step 0: 相位转复数
        C = np.exp(1j * phase_maps)
        nx, ny, nz, nc = C.shape

        # Step 1: 参考通道归一化
        if self.use_phase_correction:
            print("  Step 1/4: 参考通道归一化...")
            C_ref = C[:, :, :, self.ref_channel]
            ref_phase_norm = np.exp(1j * np.angle(C_ref))

            C_corr = np.zeros_like(C)
            for c in range(nc):
                C_corr[:, :, :, c] = C[:, :, :, c] / ref_phase_norm[:, :, :, np.newaxis].squeeze()

                if self.enhance_phase:
                    current_phase = np.angle(C_corr[:, :, :, c])
                    current_phase = gaussian_filter(current_phase, sigma=1.0)
                    C_corr[:, :, :, c] = np.exp(1j * current_phase)
        else:
            C_corr = C

        # Step 2: k-space低通滤波
        print("  Step 2/4: k-space低通滤波...")
        win = self._create_window(nx, ny, nz)

        C_filt = np.zeros_like(C_corr)
        for c in range(nc):
            Ck = fftshift(fftn(C_corr[:, :, :, c]))
            C_filtered_k = Ck * win
            C_filt[:, :, :, c] = ifftn(ifftshift(C_filtered_k))

        # 归一化相位
        for c in range(nc):
            phase_temp = np.angle(C_filt[:, :, :, c])
            C_filt[:, :, :, c] = np.exp(1j * phase_temp)

        # Step 3: 计算SMF权重
        print("  Step 3/4: 计算SMF权重...")
        Rn = self._estimate_noise_matrix(C)
        W = self._compute_weights(C, C_filt, Rn)

        # Step 4: 加权组合
        print("  Step 4/4: 相位组合...")
        I_combined = np.sum(np.conj(W) * C, axis=3)
        phase_combined = np.angle(I_combined)

        print(f"ROMAR Phase完成! 输出: [{nx}, {ny}, {nz}]")
        return phase_combined, W

    def _create_window(self, nx, ny, nz):
        """创建Hanning窗"""
        x = np.linspace(0, 1, nx)
        y = np.linspace(0, 1, ny)
        z = np.linspace(0, 1, nz)
        X, Y, Z = np.meshgrid(x, y, z, indexing='ij')

        cx, cy, cz = 0.5, 0.5, 0.5
        r = np.sqrt((X - cx)**2 + (Y - cy)**2 + (Z - cz)**2) / np.sqrt(3)

        rcut = 1.0 / self.TF
        win = np.zeros((nx, ny, nz))
        inside = r <= rcut

        t = r[inside] / (rcut + 1e-10)
        win[inside] = 0.5 * (1 + np.cos(np.pi * t))

        win = np.nan_to_num(win, nan=0.0, posinf=0.0, neginf=0.0)
        win = np.clip(win, 0, None)

        if np.max(win) > 0:
            win = win / np.max(win)

        return win

    def _estimate_noise_matrix(self, C):
        """估计噪声协方差矩阵"""
        nx, ny, nz, nc = C.shape
        C_2d = C.reshape(-1, nc)

        mag_per_voxel = np.sqrt(np.sum(np.abs(C_2d)**2, axis=1))
        thresh = np.percentile(mag_per_voxel, 5)
        noise_idx = mag_per_voxel < thresh
        noise_samples = C_2d[noise_idx, :]

        if noise_samples.shape[0] < nc:
            Rn = np.eye(nc)
        else:
            Rn = (noise_samples.conj().T @ noise_samples) / noise_samples.shape[0]

        Rn = Rn + 1e-6 * np.trace(Rn) / nc * np.eye(nc)
        Rn = (Rn + Rn.conj().T) / 2

        return Rn

    def _compute_weights(self, C_orig, C_filt, Rn):
        """计算SMF权重"""
        nx, ny, nz, nc = C_orig.shape

        try:
            Rn_inv = np.linalg.pinv(Rn)
        except:
            Rn_inv = np.eye(nc)

        W = np.zeros_like(C_orig)

        for iz in range(nz):
            if iz % max(1, nz // 5) == 0:
                print(f"    进度: {iz}/{nz}")

            for iy in range(ny):
                for ix in range(nx):
                    s = C_filt[ix, iy, iz, :]

                    if np.linalg.norm(s) < 1e-10:
                        W[ix, iy, iz, :] = np.ones(nc) / np.sqrt(nc)
                        continue

                    Rs_local = np.outer(s, s.conj())
                    P = Rn_inv @ Rs_local

                    try:
                        eigenvalues, eigenvectors = np.linalg.eig(P)
                        idx_max = np.argmax(np.real(eigenvalues))
                        wopt = eigenvectors[:, idx_max]

                        wopt_norm = np.linalg.norm(wopt)
                        if wopt_norm > 1e-10:
                            wopt = wopt / wopt_norm
                        else:
                            wopt = np.ones(nc) / np.sqrt(nc)
                    except:
                        wopt = np.ones(nc) / np.sqrt(nc)

                    W[ix, iy, iz, :] = wopt

        return W


# ========== PDF (Projection onto Dipole Fields) 实现 ==========
def dipole_kernel(matrix_size, voxel_size, B0_dir):
    """生成偶极子核"""
    nx, ny, nz = matrix_size

    # k-space坐标
    kx = np.fft.fftfreq(nx, voxel_size[0])
    ky = np.fft.fftfreq(ny, voxel_size[1])
    kz = np.fft.fftfreq(nz, voxel_size[2])

    KX, KY, KZ = np.meshgrid(kx, ky, kz, indexing='ij')

    k2 = KX**2 + KY**2 + KZ**2
    k2[k2 == 0] = 1e-10

    # 偶极子核: D = 1/3 - (k·B0)^2 / k^2
    k_dot_B0 = KX * B0_dir[0] + KY * B0_dir[1] + KZ * B0_dir[2]
    D = 1.0/3.0 - (k_dot_B0**2) / k2

    D[0, 0, 0] = 0

    return D


def PDF(iFreq, N_std, Mask, matrix_size, voxel_size, B0_dir, tol=0.05, n_CG=150):
    """
    Projection onto Dipole Fields - 去背景场

    Args:
        iFreq: 频率图
        N_std: 噪声标准差
        Mask: 脑掩膜
        matrix_size: 矩阵尺寸
        voxel_size: 体素尺寸
        B0_dir: B0方向
        tol: 容差
        n_CG: 最大迭代次数

    Returns:
        RDF: 局部场图
    """
    print(f"PDF: tol={tol}, n_CG={n_CG}")

    # 生成权重
    W = 1.0 / (N_std + 1e-10)
    W[np.isinf(W)] = 0
    W = W * (Mask > 0)
    W_var = W**2

    # 生成偶极子核
    D = dipole_kernel(matrix_size, voxel_size, B0_dir)

    # 简化版PDF：直接用高通滤波近似
    # 完整版需要实现共轭梯度求解器
    iFreq_k = fftshift(fftn(iFreq * Mask))

    # 高通滤波去除背景场
    D_highpass = 1 - np.exp(-np.abs(D) * 10)  # 简化的高通滤波
    local_field_k = iFreq_k * D_highpass

    RDF = np.real(ifftn(ifftshift(local_field_k))) * Mask

    return RDF


# ========== Tikhonov QSM反演 ==========
def tikhonov_qsm(local_field, mask, voxel_size, B0_dir, lambda_reg=0.1):
    """
    Tikhonov正则化QSM反演

    Args:
        local_field: 局部场图 (ppm)
        mask: 脑掩膜
        voxel_size: 体素尺寸
        B0_dir: B0方向
        lambda_reg: 正则化参数

    Returns:
        chi: 磁化率图 (ppm)
    """
    print(f"Tikhonov QSM: lambda={lambda_reg}")

    matrix_size = local_field.shape
    D = dipole_kernel(matrix_size, voxel_size, B0_dir)

    # Tikhonov: chi = F^-1 { D* · F{b} / (|D|^2 + lambda) }
    b_k = fftshift(fftn(local_field * mask))

    denominator = np.abs(D)**2 + lambda_reg
    denominator[denominator == 0] = 1e-10

    chi_k = (np.conj(D) * b_k) / denominator
    chi = np.real(ifftn(ifftshift(chi_k))) * mask

    return chi


# ========== Vesselness 滤波器 ==========
def vesselness_3d(image, scales=[0.2, 0.4, 0.8, 1.2], alpha=0.5, beta=0.5, c=500):
    """
    3D Frangi vesselness滤波器（简化版）

    Args:
        image: 3D图像
        scales: 尺度列表
        alpha, beta, c: Frangi参数

    Returns:
        vesselness: 血管增强图
    """
    print(f"Vesselness 3D: scales={scales}")

    vesselness_all = []

    for sigma in scales:
        # 使用高斯滤波的Hessian矩阵特征值近似
        # 简化版：使用梯度幅值作为血管度量
        grad_x = gaussian_filter(image, sigma=sigma, order=[1, 0, 0])
        grad_y = gaussian_filter(image, sigma=sigma, order=[0, 1, 0])
        grad_z = gaussian_filter(image, sigma=sigma, order=[0, 0, 1])

        grad_mag = np.sqrt(grad_x**2 + grad_y**2 + grad_z**2)

        # 归一化
        if np.max(grad_mag) > 0:
            grad_mag = grad_mag / np.max(grad_mag)

        vesselness_all.append(grad_mag)

    # 取所有尺度的最大值
    vesselness = np.maximum.reduce(vesselness_all)

    return vesselness


# ========== 主流程 ==========
def main():
    print("=" * 60)
    print("QSM-ROMAR Pipeline (Python版)")
    print("=" * 60)

    # ========== 参数设置 ==========
    # 这里需要根据你的实际数据路径修改
    data_dir = Path("code_test/data")

    # 模拟数据（实际使用时需要替换为真实数据加载）
    print("\n[警告] 这是演示代码，需要替换为实际数据加载")
    print("请修改以下部分以加载你的Bruker数据：")
    print("  - phase_data: 多通道相位数据 [nx, ny, nz, ncoils]")
    print("  - mag_data: 幅值数据 [nx, ny, nz]")
    print("  - mask: 脑掩膜 [nx, ny, nz]")
    print("  - voxel_size: 体素尺寸 [dx, dy, dz] (mm)")
    print("  - B0_dir: B0方向 [x, y, z]")
    print("  - TE: 回波时间 (s)")
    print("  - B0: 主磁场强度 (T)")

    # 示例参数
    nx, ny, nz, nc = 128, 128, 64, 4
    phase_data = np.random.randn(nx, ny, nz, nc) * 0.5  # 替换为实际数据
    mag_data = np.random.rand(nx, ny, nz) + 0.5  # 替换为实际数据
    mask = np.ones((nx, ny, nz))  # 替换为实际掩膜

    voxel_size = np.array([0.2, 0.2, 0.5])  # mm
    B0_dir = np.array([0, 0, 1])  # z方向
    TE = 0.01  # 10ms
    B0 = 9.4  # Tesla

    # ========== Step 1: ROMAR相位合并 ==========
    print("\n" + "=" * 60)
    print("Step 1: ROMAR相位合并")
    print("=" * 60)

    romar = ROMARPhase(TF=10, enhance_phase=False)
    phase_combined, W = romar.process(phase_data)

    # ========== Step 2: RDF去背景场 ==========
    print("\n" + "=" * 60)
    print("Step 2: RDF去背景场")
    print("=" * 60)

    N_std = np.ones_like(phase_combined) * 0.1  # 噪声标准差
    RDF = PDF(phase_combined, N_std, mask, phase_combined.shape, voxel_size, B0_dir, tol=0.05, n_CG=150)

    # 轻度去噪
    RDF_denoised = gaussian_filter(RDF, sigma=0.5)

    # ========== Step 3: QSM反演 ==========
    print("\n" + "=" * 60)
    print("Step 3: QSM反演 (Tikhonov)")
    print("=" * 60)

    # 转换为ppm
    gamma = 42.6  # MHz/T
    local_field_ppm = RDF_denoised / (TE * gamma * 2 * np.pi * B0)

    chi_map = tikhonov_qsm(local_field_ppm, mask, voxel_size, B0_dir, lambda_reg=0.1)

    # 轻度平滑
    chi_map_smooth = gaussian_filter(chi_map, sigma=0.5)

    # ========== Step 4: 血管增强 ==========
    print("\n" + "=" * 60)
    print("Step 4: 血管增强")
    print("=" * 60)

    # QSM血管增强
    qsm_normalized = (chi_map_smooth - np.min(chi_map_smooth)) * mask
    qsm_vessel = vesselness_3d(qsm_normalized, scales=[0.2, 0.4, 0.8, 1.2])
    qsm_vessel = qsm_vessel * mask

    # R2*计算
    r2star = -np.log(mag_data + 1e-6) * mask
    r2star = np.clip(r2star, 0, None)
    r2star[np.isnan(r2star) | np.isinf(r2star)] = 0

    # R2*血管增强
    r2star_vessel = vesselness_3d(r2star, scales=[0.2, 0.4, 0.8, 1.2])
    r2star_vessel = r2star_vessel * mask

    # ========== Step 5: 结果对比 ==========
    print("\n" + "=" * 60)
    print("Step 5: 结果对比")
    print("=" * 60)

    qsm_contrast = np.std(qsm_vessel[mask > 0]) / (np.mean(qsm_vessel[mask > 0]) + 1e-10)
    r2star_contrast = np.std(r2star_vessel[mask > 0]) / (np.mean(r2star_vessel[mask > 0]) + 1e-10)

    print(f"QSM血管对比度: {qsm_contrast:.4f}")
    print(f"R2*血管对比度: {r2star_contrast:.4f}")
    print(f"对比度比值 (QSM/R2*): {qsm_contrast/r2star_contrast:.4f}")

    # ========== 可视化 ==========
    mid_slice = nz // 2

    fig, axes = plt.subplots(2, 3, figsize=(15, 10))

    axes[0, 0].imshow(phase_combined[:, :, mid_slice], cmap='jet')
    axes[0, 0].set_title('ROMAR相位')
    axes[0, 0].axis('off')

    axes[0, 1].imshow(RDF_denoised[:, :, mid_slice], cmap='gray')
    axes[0, 1].set_title('RDF局部场')
    axes[0, 1].axis('off')

    axes[0, 2].imshow(chi_map_smooth[:, :, mid_slice], cmap='gray')
    axes[0, 2].set_title('QSM磁化率图')
    axes[0, 2].axis('off')

    axes[1, 0].imshow(qsm_vessel[:, :, mid_slice], cmap='hot')
    axes[1, 0].set_title('QSM血管增强')
    axes[1, 0].axis('off')

    axes[1, 1].imshow(r2star[:, :, mid_slice], cmap='gray')
    axes[1, 1].set_title('R2*')
    axes[1, 1].axis('off')

    axes[1, 2].imshow(r2star_vessel[:, :, mid_slice], cmap='hot')
    axes[1, 2].set_title('R2*血管增强')
    axes[1, 2].axis('off')

    plt.tight_layout()
    plt.savefig('qsm_romar_results.png', dpi=150, bbox_inches='tight')
    print("\n结果已保存至: qsm_romar_results.png")

    plt.show()

    print("\n" + "=" * 60)
    print("处理完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
