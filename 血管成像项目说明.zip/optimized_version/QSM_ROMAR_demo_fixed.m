im_dir='code_test\data\raw\1_1\pdata\4\dicom';
re_dir='code_test\data\raw\1_1\pdata\3\dicom';
raw_dir='code_test\data\raw\1_1';
ph_dir='code_test\data\raw\1_1\pdata\2\dicom';
mag_dir='code_test\data\raw\1_1\pdata\1\dicom';


[iField, CF, B0_dir, Affine3D, TE, delta_TE, matrix_size, voxel_size,NumEcho]=read_bruker_zyj(raw_dir,re_dir, im_dir);
figure,imshow3(abs(iField),[]);

phs=read_bruker_real_zyj(ph_dir,NumEcho);
phase_data=phs;

% ========== 读取幅值数据用于R2*计算 ==========
mag_data = read_bruker_real_zyj(mag_dir, NumEcho);
magecho = abs(mag_data);  % 修复：定义magecho变量
fprintf('幅值数据尺寸: [%s]\n', num2str(size(magecho)));

% ========== ROMAR 相位合并（优化参数）==========
romar_params = struct();
romar_params.TF = 10;                    % 降低TF，减少过度平滑 (原来12)
romar_params.ref_channel = 1;
romar_params.use_phase_correction = true;
romar_params.enhance_phase = false;      % 关闭额外平滑，保留细节

C_data = double(phs);
[I_romar, W_romar] = ROMAR_phase(C_data, romar_params);

[iFreq_raw, N_std] = Fit_ppm_complex(iField);



out_dir='test\code_test\data\mask\1_1';
rawmask_dirz=fullfile(out_dir,'1.nii.gz');
rawmask=niftiread(rawmask_dirz)-1;

bm_ero=[2,2,2];
rawbrain_mask_ero3vox = double(brainMask_erosion(rawmask, bm_ero, '3D'));

% ========== RDF 优化参数 ==========
% 修复：PDF参数调整，提高容错度
tol_rdf = 0.05;        % 容差从1e-5提高到0.05 (更宽松)
n_iter = 150;          % 迭代次数从100增加到150
RDF = PDF(I_romar, N_std, rawbrain_mask_ero3vox, matrix_size, voxel_size, B0_dir, tol_rdf, n_iter);
figure(94),imshow3(RDF,[]);title('RDF (优化参数)');

% ========== 轻度去噪（保留血管细节）==========
denoiseRDF = imgaussfilt3(RDF, 0.5);  % 降低高斯核大小，减少模糊

B0=9.4;

% Susceptibility map estimation using Tikhonov regularisation
denoiseRDFlocal_field_ppm = denoiseRDF/(delta_TE*42.6*2*pi*B0);





par.Resolution = voxel_size;
par.Orientation = B0_dir;
[denoiseRDFsusc_map_ppm, denoiseRDFalpha, ~] = ...
    directTikhonov_lcurve(denoiseRDFlocal_field_ppm,rawbrain_mask_ero3vox, par);



% ndi_params = struct();
% ndi_params.Resolution = voxel_size;
% ndi_params.Orientation = B0_dir;
% ndi_params.lambda = 0.001;
% ndi_params.max_iter = 450;
% ndi_params.alpha = 1.0;
% ndi_params.use_Tikhonov = true;
% ndi_params.B0 = B0;
%
% [denoiseRDFsusc_map_ppm, ndi_info] = ...
%     NDI_inversion(denoiseRDFlocal_field_ppm, rawbrain_mask_ero3vox, ndi_params);



figure(95),imshow3(denoiseRDFsusc_map_ppm,[]);

brain_mask_ero3vox=rawbrain_mask_ero3vox;
deQSM=imgaussfilt3(denoiseRDFsusc_map_ppm, 0.5);  % 降低平滑强度
prem=deQSM;


fanprem=prem;
figure,imshow3(fanprem,[]);
nfanm=(fanprem-min(fanprem(:))).*brain_mask_ero3vox;

fan=[];
nn=10;
slicenumn=size(nfanm,3)/nn;
for i=1:slicenumn
    fan(:,:,i)=max(nfanm(:,:,1+nn*(i-1):nn*i),[],3);
end
figure(96),imshow3(fan,[]);title('fan max 10');


bm_ero_2=[6,6,6];
brain_mask_ero3vox_2 = brainMask_erosion(brain_mask_ero3vox, bm_ero_2, '3D');

% ========== QSM 血管增强（优化参数）==========
% 调整vesselness参数以更好匹配血管尺度
vessel_scales = [0.2, 0.4, 0.8, 1.2];  % 增加尺度范围
nfanmvessel=vesselness3D(imrotate(imgaussfilt3(permute((fanprem-min(fanprem(:))),[2,3,1]), 0.5),90), ...
    vessel_scales,[1,1,1],1,true).*imrotate(permute(brain_mask_ero3vox_2,[2,3,1]),90);

n=25;
slicenum=size(nfanmvessel,3)/n;
mvesselminipmtrm=[];
% nfanmvesselv=imgaussfilt3(nfanmvessel).*brain_mask_ero3vox_2;
for i=1:n
    mvesselminipmtrm(:,:,i)=max(nfanmvessel(:,:,(1+(i-1)*slicenum):i*slicenum),[],3);
end
figure,imshow3(mvesselminipmtrm,[]);title('QSM enhanced vessel (优化)');
% colormap default;
figure,imshow3(max(mvesselminipmtrm(:,:,3:8),[],3),[]);
figure,imshow(max(mvesselminipmtrm(:,:,3:8),[],3),[]);
figure,imshow3(max(mvesselminipmtrm(:,:,9:11),[],3),[]);
figure,imshow3(max(mvesselminipmtrm(:,:,12:15),[],3),[]);

% ========== R2* 计算（修复bug）==========
% 修复：使用正确的magecho变量
if size(magecho, 4) > 1
    % 多回波：使用第一个回波
    mag_first_echo = squeeze(magecho(:,:,:,1));
else
    mag_first_echo = magecho;
end

% R2* = -ln(S/S0) / TE，这里简化为 -ln(S)
r2star = -log(mag_first_echo + 1e-6) .* brain_mask_ero3vox;
r2star(r2star < 0) = 0;  % 去除负值
r2star(isinf(r2star) | isnan(r2star)) = 0;  % 去除异常值

figure,imshow3(r2star,[]);title('R2* (修复)');


bm_ero_2=[6,6,6];
brain_mask_ero3vox_2 = brainMask_erosion(brain_mask_ero3vox, bm_ero_2, '3D');

% ========== R2* 血管增强（优化参数）==========
r2starvessel=vesselness3D(imrotate(imgaussfilt3(permute(r2star,[2,3,1]), 0.5),90), ...
    vessel_scales,[1,1,1],1,true).*imrotate(permute(brain_mask_ero3vox_2,[2,3,1]),90);

n=25;
slicenum=size(r2starvessel,3)/n;
r2startvesselvesselminipmtrm=[];
% nfanmvesselv=imgaussfilt3(nfanmvessel).*brain_mask_ero3vox_2;
for i=1:n
    r2startvesselvesselminipmtrm(:,:,i)=max(r2starvessel(:,:,(1+(i-1)*slicenum):i*slicenum),[],3);
end
figure,imshow3(r2startvesselvesselminipmtrm,[]);title('R2* enhanced vessel');
% colormap default;

figure,imshow(max(r2startvesselvesselminipmtrm(:,:,3:8),[],3),[]);
figure,imshow3(max(r2startvesselvesselminipmtrm(:,:,9:11),[],3),[]);
figure,imshow3(max(r2startvesselvesselminipmtrm(:,:,12:15),[],3),[]);

% ========== 对比分析 ==========
fprintf('\n========== 结果对比 ==========\n');
fprintf('QSM血管对比度: %.4f\n', std(mvesselminipmtrm(:))/mean(mvesselminipmtrm(:)));
fprintf('R2*血管对比度: %.4f\n', std(r2startvesselvesselminipmtrm(:))/mean(r2startvesselvesselminipmtrm(:)));

% 并排对比显示
figure('Name', 'QSM vs R2* 血管对比', 'Position', [100, 100, 1200, 400]);
subplot(1,2,1);
imshow(max(mvesselminipmtrm(:,:,3:8),[],3),[]);
title('QSM 血管增强', 'FontSize', 14, 'FontWeight', 'bold');
colormap(gca, hot);

subplot(1,2,2);
imshow(max(r2startvesselvesselminipmtrm(:,:,3:8),[],3),[]);
title('R2* 血管增强', 'FontSize', 14, 'FontWeight', 'bold');
colormap(gca, hot);

sgtitle('QSM vs R2* 血管提取对比', 'FontSize', 16, 'FontWeight', 'bold');
