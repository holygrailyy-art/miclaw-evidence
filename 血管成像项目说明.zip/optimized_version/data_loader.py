#!/usr/bin/env python3
"""
加载 Bruker 数据的辅助函数
"""

import numpy as np
import nibabel as nib
from pathlib import Path
import struct


def load_bruker_phase_from_nifti(nifti_path):
    """
    从NIfTI文件加载相位数据

    Args:
        nifti_path: NIfTI文件路径

    Returns:
        phase_data: 相位数据 (弧度)
        affine: 仿射矩阵
        header: NIfTI头信息
    """
    nii = nib.load(nifti_path)
    phase_data = nii.get_fdata()

    # 如果相位范围在[0, 4096]之类，需要归一化到[-pi, pi]
    if phase_data.max() > 10:
        phase_data = (phase_data / phase_data.max()) * 2 * np.pi - np.pi

    return phase_data, nii.affine, nii.header


def load_bruker_magnitude_from_nifti(nifti_path):
    """
    从NIfTI文件加载幅值数据

    Args:
        nifti_path: NIfTI文件路径

    Returns:
        mag_data: 幅值数据
    """
    nii = nib.load(nifti_path)
    mag_data = nii.get_fdata()

    return mag_data


def load_mask_from_nifti(nifti_path):
    """
    从NIfTI文件加载掩膜

    Args:
        nifti_path: NIfTI文件路径

    Returns:
        mask: 二值掩膜
    """
    nii = nib.load(nifti_path)
    mask = nii.get_fdata()

    # 确保是二值掩膜
    mask = (mask > 0).astype(np.float32)

    return mask


def erode_mask_3d(mask, erosion_size=[2, 2, 2]):
    """
    3D掩膜腐蚀

    Args:
        mask: 输入掩膜
        erosion_size: 腐蚀尺寸 [x, y, z]

    Returns:
        eroded_mask: 腐蚀后的掩膜
    """
    from scipy.ndimage import binary_erosion

    # 创建结构元素
    struct_elem = np.ones(erosion_size)

    eroded_mask = binary_erosion(mask, structure=struct_elem).astype(np.float32)

    return eroded_mask


def get_voxel_size_from_nifti(nifti_path):
    """
    从NIfTI文件获取体素尺寸

    Args:
        nifti_path: NIfTI文件路径

    Returns:
        voxel_size: [dx, dy, dz] in mm
    """
    nii = nib.load(nifti_path)
    voxel_size = nii.header.get_zooms()[:3]

    return np.array(voxel_size)


# ========== 实际数据加载示例 ==========
def load_your_data():
    """
    加载你的实际数据
    根据你的数据格式修改这个函数
    """

    # 示例：如果你的数据已经转换为NIfTI格式
    data_dir = Path("code_test/data")

    # 方式1：从NIfTI加载
    # phase_path = data_dir / "phase.nii.gz"
    # mag_path = data_dir / "magnitude.nii.gz"
    # mask_path = data_dir / "mask.nii.gz"

    # phase_data, _, _ = load_bruker_phase_from_nifti(phase_path)
    # mag_data = load_bruker_magnitude_from_nifti(mag_path)
    # mask = load_mask_from_nifti(mask_path)
    # voxel_size = get_voxel_size_from_nifti(phase_path)

    # 方式2：如果你有MATLAB .mat文件
    # from scipy.io import loadmat
    # mat_data = loadmat("your_data.mat")
    # phase_data = mat_data['phase']
    # mag_data = mat_data['magnitude']
    # mask = mat_data['mask']
    # voxel_size = mat_data['voxel_size'].flatten()

    # 方式3：如果你有原始Bruker数据
    # 需要使用bruker2nifti或类似工具先转换

    # 临时返回None，提示用户修改
    return None, None, None, None


if __name__ == "__main__":
    print("数据加载工具函数")
    print("\n支持的数据格式:")
    print("1. NIfTI (.nii, .nii.gz)")
    print("2. MATLAB (.mat)")
    print("3. NumPy (.npy)")
    print("\n请根据你的数据格式修改 load_your_data() 函数")
