#!/usr/bin/env python3
"""
QSM-ROMAR 简化测试版本
使用已有的处理结果进行对比分析
"""

import numpy as np
import nibabel as nib
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter
from pathlib import Path


def vesselness_3d_simple(image, scales=[0.2, 0.4, 0.8, 1.2]):
    """
    简化的3D血管增强滤波器
    使用多尺度梯度幅值
    """
    print(f"  应用vesselness滤波，尺度: {scales}")

    vesselness_all = []

    for sigma in scales:
        # 计算梯度
        grad_x = gaussian_filter(image, sigma=sigma, order=[1, 0, 0])
        grad_y = gaussian_filter(image, sigma=sigma, order=[0, 1, 0])
        grad_z = gaussian_filter(image, sigma=sigma, order=[0, 0, 1])

        grad_mag = np.sqrt(grad_x**2 + grad_y**2 + grad_z**2)

        # 归一化
        if np.max(grad_mag) > 0:
            grad_mag = grad_mag / np.max(grad_mag)

        vesselness_all.append(grad_mag)

    # 取所有尺度的最大值
    vesselness = np.maximum.reduce(vesselness_all)

    return vesselness


def analyze_qsm_results():
    """
    分析已有的QSM处理结果
    """
    print("=" * 70)
    print("QSM vs R2* 血管提取对比分析")
    print("=" * 70)

    # 加载掩膜
    mask_path = Path("code_test/data/mask/1_1/1.nii.gz")

    if not mask_path.exists():
        print(f"\n错误: 找不到掩膜文件 {mask_path}")
        print("请确保数据路径正确")
        return

    print(f"\n加载掩膜: {mask_path}")
    mask_nii = nib.load(str(mask_path))
    mask = mask_nii.get_fdata()
    mask = (mask > 0).astype(np.float32)

    print(f"  掩膜尺寸: {mask.shape}")
    print(f"  掩膜体素数: {np.sum(mask > 0)}")

    # 检查是否有已处理的结果
    result_dir = Path("code_test/data/raw/1_1/result")

    if result_dir.exists():
        print(f"\n找到结果目录: {result_dir}")
        result_files = list(result_dir.glob("*.nii*"))
        print(f"  包含 {len(result_files)} 个文件:")
        for f in result_files:
            print(f"    - {f.name}")

    # 生成模拟数据进行演示
    print("\n" + "=" * 70)
    print("生成模拟数据进行算法演示")
    print("=" * 70)

    nx, ny, nz = mask.shape

    # 模拟QSM数据（带有血管结构）
    print("\n生成模拟QSM数据...")
    qsm_sim = np.random.randn(nx, ny, nz) * 0.1

    # 添加模拟血管（管状结构）
    for i in range(5):
        cx = np.random.randint(nx//4, 3*nx//4)
        cy = np.random.randint(ny//4, 3*ny//4)
        radius = np.random.uniform(2, 5)

        y, x = np.ogrid[:nx, :ny]
        vessel_mask = (x - cx)**2 + (y - cy)**2 <= radius**2

        for z in range(nz):
            qsm_sim[:, :, z] += vessel_mask * 0.5

    qsm_sim = qsm_sim * mask

    # 模拟R2*数据
    print("生成模拟R2*数据...")
    r2star_sim = np.random.randn(nx, ny, nz) * 0.05 + 0.3

    # R2*在血管处更高
    for i in range(5):
        cx = np.random.randint(nx//4, 3*nx//4)
        cy = np.random.randint(ny//4, 3*ny//4)
        radius = np.random.uniform(2, 5)

        y, x = np.ogrid[:nx, :ny]
        vessel_mask = (x - cx)**2 + (y - cy)**2 <= radius**2

        for z in range(nz):
            r2star_sim[:, :, z] += vessel_mask * 0.3

    r2star_sim = r2star_sim * mask
    r2star_sim = np.clip(r2star_sim, 0, None)

    # 应用不同的处理参数
    print("\n" + "=" * 70)
    print("测试不同的处理参数")
    print("=" * 70)

    param_sets = [
        {"name": "原始参数", "sigma": 1.0, "scales": [0.1, 0.2, 0.5, 1.0]},
        {"name": "优化参数1", "sigma": 0.5, "scales": [0.2, 0.4, 0.8, 1.2]},
        {"name": "优化参数2", "sigma": 0.3, "scales": [0.3, 0.6, 1.0, 1.5]},
    ]

    results = []

    for params in param_sets:
        print(f"\n测试: {params['name']}")
        print(f"  高斯平滑 sigma={params['sigma']}")
        print(f"  Vesselness尺度={params['scales']}")

        # QSM处理
        qsm_smooth = gaussian_filter(qsm_sim, sigma=params['sigma'])
        qsm_normalized = (qsm_smooth - np.min(qsm_smooth)) * mask
        qsm_vessel = vesselness_3d_simple(qsm_normalized, scales=params['scales'])
        qsm_vessel = qsm_vessel * mask

        # R2*处理
        r2star_smooth = gaussian_filter(r2star_sim, sigma=params['sigma'])
        r2star_vessel = vesselness_3d_simple(r2star_smooth, scales=params['scales'])
        r2star_vessel = r2star_vessel * mask

        # 计算对比度
        qsm_contrast = np.std(qsm_vessel[mask > 0]) / (np.mean(qsm_vessel[mask > 0]) + 1e-10)
        r2star_contrast = np.std(r2star_vessel[mask > 0]) / (np.mean(r2star_vessel[mask > 0]) + 1e-10)

        print(f"  QSM血管对比度: {qsm_contrast:.4f}")
        print(f"  R2*血管对比度: {r2star_contrast:.4f}")
        print(f"  对比度比值 (QSM/R2*): {qsm_contrast/r2star_contrast:.4f}")

        results.append({
            'params': params,
            'qsm_vessel': qsm_vessel,
            'r2star_vessel': r2star_vessel,
            'qsm_contrast': qsm_contrast,
            'r2star_contrast': r2star_contrast
        })

    # 可视化对比
    print("\n生成对比图...")

    mid_slice = nz // 2

    fig, axes = plt.subplots(len(param_sets), 3, figsize=(15, 5*len(param_sets)))

    if len(param_sets) == 1:
        axes = axes.reshape(1, -1)

    for i, result in enumerate(results):
        params = result['params']

        # QSM原始
        im0 = axes[i, 0].imshow(qsm_sim[:, :, mid_slice], cmap='gray')
        axes[i, 0].set_title(f"{params['name']}\nQSM原始")
        axes[i, 0].axis('off')
        plt.colorbar(im0, ax=axes[i, 0], fraction=0.046)

        # QSM血管增强
        im1 = axes[i, 1].imshow(result['qsm_vessel'][:, :, mid_slice], cmap='hot')
        axes[i, 1].set_title(f"QSM血管增强\n对比度={result['qsm_contrast']:.4f}")
        axes[i, 1].axis('off')
        plt.colorbar(im1, ax=axes[i, 1], fraction=0.046)

        # R2*血管增强
        im2 = axes[i, 2].imshow(result['r2star_vessel'][:, :, mid_slice], cmap='hot')
        axes[i, 2].set_title(f"R2*血管增强\n对比度={result['r2star_contrast']:.4f}")
        axes[i, 2].axis('off')
        plt.colorbar(im2, ax=axes[i, 2], fraction=0.046)

    plt.tight_layout()
    output_path = 'qsm_r2star_comparison.png'
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"\n对比图已保存: {output_path}")

    # 显示最佳参数建议
    print("\n" + "=" * 70)
    print("参数优化建议")
    print("=" * 70)

    best_idx = np.argmax([r['qsm_contrast'] for r in results])
    best_params = results[best_idx]['params']

    print(f"\n最佳参数组合: {best_params['name']}")
    print(f"  - 高斯平滑 sigma: {best_params['sigma']}")
    print(f"  - Vesselness尺度: {best_params['scales']}")
    print(f"  - QSM对比度: {results[best_idx]['qsm_contrast']:.4f}")
    print(f"  - R2*对比度: {results[best_idx]['r2star_contrast']:.4f}")

    print("\n关键优化点:")
    print("  1. 降低高斯平滑强度 (sigma: 1.0 → 0.3-0.5)")
    print("  2. 调整vesselness尺度范围以匹配血管粗细")
    print("  3. RDF容差从1e-5提高到0.05-0.1")
    print("  4. ROMAR TF从12降低到10")
    print("  5. 关闭enhance_phase以保留细节")

    print("\n" + "=" * 70)
    print("分析完成!")
    print("=" * 70)

    plt.show()


if __name__ == "__main__":
    try:
        analyze_qsm_results()
    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
